<?php

/***************************************************************
 * Appstudioz Technologies Pvt. Ltd.
 * File Name   : Users.php
 * File Description  : Users
 * Created By : Saurabh Singh Jadon
 * Created Date: 11 September 2013
 ***************************************************************/
 
class Application_Model_Reports extends Zend_Db_Table_Abstract
{
    public function getTravelDistanceByDate($params)
	{
		$db =  Zend_Db_Table::getDefaultAdapter();
		 $query = "SELECT  CONCAT(DATE(up.add_date_time), cl.Call_Log_No) AS groupbyfield, DATE(up.add_date_time) AS add_date, DATE_FORMAT(up.add_date_time,'%H:%i:%s') TIMEONLY, sum(up.travelled_distance) as distance_travelled,
		lum.StaffCode, lum.StaffName, cl.Customer_Name, cl.Site_ID, cl.Customer_ID, cl.SiteAdd1, cl.Call_Log_No, cl.site_latitude, cl.site_longitude, cl.IndusTTNumber
		FROM 
		user_path AS up 
		INNER JOIN local_user_mapping AS lum on (lum.StaffCode=up.mob_user_staff_code)
		INNER JOIN call_log AS cl on (up.Call_Log_No=cl.Call_Log_No)

		WHERE up.mob_user_staff_code=? and DATE(up.add_date_time) BETWEEN ? and ? and up.Call_Log_No!='0' group by groupbyfield order by add_date asc";

		return $result = $db->fetchAll($query, array($params['user_dis'], $params['distance_from'], $params['distance_to']));
	}
	
    public function getTimeSpendByDate($params)
	{
		$db =  Zend_Db_Table::getDefaultAdapter();
		$resultArr = array();
		// Start query for at site
	    $query = "SELECT CONCAT(DATE(up.add_date_time), cl.Call_Log_No,up.random_string) AS groupbyfield, DATE(up.add_date_time) AS add_date, DATE_FORMAT(up.add_date_time,'%H:%i:%s') TIMEONLY, sum(up.travelled_distance) as distance_travelled,
		lum.StaffCode, lum.StaffName, cl.Customer_Name, cl.Site_ID, cl.Customer_ID, cl.SiteAdd1, cl.Call_Log_No, cl.site_latitude, cl.site_longitude, cl.IndusTTNumber,

		(select concat(lat,'/',longitude) as latlong from user_path where Call_Log_No=up.Call_Log_No and move_status='at_site' and random_string = up.random_string and DATE(add_date_time)=DATE(up.add_date_time) order by id asc limit 1) as atsite_startlatlong,
		
		(select concat(lat,'/',longitude) as latlong from user_path where Call_Log_No=up.Call_Log_No and move_status='at_site' and random_string = up.random_string and DATE(add_date_time)=DATE(up.add_date_time) order by id desc limit 1) as atsite_endlatlong,
		
		(select SUM(time_spend) as time_spend from user_path where Call_Log_No=up.Call_Log_No and move_status='at_site' and random_string = up.random_string and DATE(add_date_time)=DATE(up.add_date_time) ) as atsite_time_spend,
		
		(select SUM(time_spend) as total_time_spend from user_path where mob_user_staff_code=up.mob_user_staff_code and random_string = up.random_string and  move_status='at_site' and DATE(add_date_time)=DATE(up.add_date_time)) as atsite_total_time_spend,

		(select concat(lat,'/',longitude) as latlong from user_path where Call_Log_No=up.Call_Log_No and random_string = up.random_string and move_status='notmoving' and DATE(add_date_time)=DATE(up.add_date_time) order by id asc limit 1) as notmoving_startlatlong,
		
		(select concat(lat,'/',longitude) as latlong from user_path where Call_Log_No=up.Call_Log_No and random_string = up.random_string and move_status='notmoving' and DATE(add_date_time)=DATE(up.add_date_time) order by id desc limit 1) as notmoving_endlatlong,
		
		(select SUM(time_spend) as time_spend from user_path where Call_Log_No=up.Call_Log_No and  random_string = up.random_string and move_status='notmoving' and DATE(add_date_time)=DATE(up.add_date_time) ) as notmoving_time_spend,	
		
        (select SUM(time_spend) as total_time_spend from user_path where mob_user_staff_code=up.mob_user_staff_code and random_string = up.random_string and  move_status='notmoving' and DATE(add_date_time)=DATE(up.add_date_time)) as notmoving_total_time_spend,		
		
		(select concat(lat,'/',longitude) as latlong from user_path where Call_Log_No=up.Call_Log_No and random_string = up.random_string and move_status='moving' and DATE(add_date_time)=DATE(up.add_date_time) order by id asc limit 1) as moving_startlatlong,
		
		(select concat(lat,'/',longitude) as latlong from user_path where Call_Log_No=up.Call_Log_No and random_string = up.random_string and move_status='moving' and DATE(add_date_time)=DATE(up.add_date_time) order by id desc limit 1) as moving_endlatlong,
		
		(select SUM(time_spend) as time_spend from user_path where Call_Log_No=up.Call_Log_No and random_string = up.random_string and move_status='moving' and DATE(add_date_time)=DATE(up.add_date_time) ) as moving_time_spend,
        (select SUM(time_spend) as total_time_spend from user_path where mob_user_staff_code=up.mob_user_staff_code and random_string = up.random_string and  move_status='moving' and DATE(add_date_time)=DATE(up.add_date_time)) as moving_total_time_spend	
		
		FROM 
		user_path AS up 
		INNER JOIN local_user_mapping AS lum on (lum.StaffCode=up.mob_user_staff_code)
		INNER JOIN call_log AS cl on (up.Call_Log_No=cl.Call_Log_No)
		WHERE up.mob_user_staff_code='".$params['user_spend']."' and DATE(up.add_date_time) BETWEEN '".$params['time_spend_from']."' and '".$params['time_spend_to']."' and up.Call_Log_No!='0' and up.random_string !='' group by groupbyfield order by add_date asc";
		
		$result = $db->fetchAll($query);
		return $result;
	}
	
    public function getTicketReportByDate($params)
	{
/* 		$db =  Zend_Db_Table::getDefaultAdapter();
		$query = "SELECT  DATE(track_date) AS add_date, Call_Log_No, mob_user_cmsstaff_code FROM user_site_track WHERE DATE(track_date) BETWEEN ? and ? and status='left_site' group by add_date,Call_Log_No order by add_date asc";  
		return $result = $db->fetchAll($query, array($params['user_attend'], $params['ticket_from'], $params['ticket_to'])); */
	}
	
    public function getAttendanceByDate($params)
	{
		$db =  Zend_Db_Table::getDefaultAdapter();
  $query = "SELECT  DATE(a.attend_date) AS add_date, 
						DATE_FORMAT(a.attend_date,'%H:%i:%s') TIMEONLY,
						lum.StaffCode, lum.StaffName, a.attend_date, a.latitude, a.longitude, a.logout_date, 
						a.end_latitude,a.end_longitude, if(a.status=2,'Field user logout properly', 'Field user not logout properly')	as daystatus, 
						TIMESTAMPDIFF(SECOND, attend_date, logout_date)/3600 as total_time
		FROM 
		attendance AS a 
		INNER JOIN local_user_mapping AS lum on (lum.StaffCode=a.mob_user_staff_code)

		WHERE a.mob_user_staff_code='".$params['user_attend']."' and DATE(a.attend_date) BETWEEN '".$params['attendance_from']."' and '".$params['attendance_to']."' order by attend_date desc";
		return $result = $db->fetchAll($query, array($params['user_attend'], $params['attendance_from'], $params['attendance_to']));
	}
	
	public function getSiteVisitByDate($params)
	{
		$db =  Zend_Db_Table::getDefaultAdapter();
		$query = "SELECT  DATE(track_date) as add_date, count(DISTINCT Call_Log_No) as total_visit  FROM user_site_track WHERE status='at_site'  and mob_user_staff_code=? and DATE(track_date) BETWEEN ? and ? group by add_date  order by add_date asc";  
		return $result = $db->fetchAll($query, array($params['user_visit'], $params['sitevisit_from'], $params['sitevisit_to']));
	}
	
	public function getTotalTravelledDistance($user_visit,$date)
	{
		$db =  Zend_Db_Table::getDefaultAdapter();
		$query = "select sum(travelled_distance) AS total_distance_travelled from user_path  WHERE 
				mob_user_staff_code=? and DATE(add_date_time)=?
				group by DATE(add_date_time)";
			$result = $db->fetchRow($query, array($user_visit,$date));
			return $result['total_distance_travelled'];		
	}
	
	public function getStartLatLong($user_visit,$date)
	{
		$db =  Zend_Db_Table::getDefaultAdapter();
		$query = "select lat,longitude from user_path  WHERE 
			mob_user_staff_code=? and DATE(add_date_time)=?
			order by id asc limit 1";
			return $result = $db->fetchRow($query, array($user_visit,$date));
	}

	public function getEndLatLong($user_visit,$date)
	{
		$db =  Zend_Db_Table::getDefaultAdapter();
		$query = "select lat,longitude from user_path  WHERE 
			mob_user_staff_code=? and DATE(add_date_time)=?
			order by id desc limit 1";
			return $result = $db->fetchRow($query, array($user_visit,$date));
	}
	
	public function getTotalSiteVisitCountByEmp($staffcode, $datefrom, $dateto)
	{
		$db =  Zend_Db_Table::getDefaultAdapter();
		$query = "select count(Call_Log_No) as totalvisit from user_site_track where status='at_site' and mob_user_staff_code=? and track_date BETWEEN ? and ?";
		$result = $db->fetchRow($query, array($staffcode, $datefrom, $dateto));
		return $result['totalvisit'];
	}
	
	public function getTotalSiteCloseByEmp($staffcode, $date)
	{
		$db =  Zend_Db_Table::getDefaultAdapter();
		$query = "select count(Call_Log_No) as totalclose from day_wise_ticket_status where job_process_status='Closed' and mob_user_staff_code='".$staffcode."' and track_date='".$date."'";
		$result = $db->fetchRow($query, array($staffcode, $datefrom, $dateto));
		return $result['totalclose'];
	}

	public function getTotalSitePendingByEmp($staffcode, $date)
	{
		$db =  Zend_Db_Table::getDefaultAdapter();
		$query = "select count(Distinct Call_Log_No) as totalpending from day_wise_ticket_status where job_process_status='Pending' and mob_user_staff_code='".$staffcode."' and track_date='".$date."'";
		$result = $db->fetchRow($query, array($staffcode, $datefrom, $dateto));
		return $result['totalpending'];
	}
	
    public function getTravelSiteCountByDate($params)
	{
		$db =  Zend_Db_Table::getDefaultAdapter();
	
		$query = "SELECT  CONCAT(DATE(ust.track_date), cl.Call_Log_No) AS groupbyfield, DATE(ust.track_date) AS add_date, DATE_FORMAT(ust.track_date,'%H:%i:%s') TIMEONLY,
		lum.StaffCode, lum.StaffName,a.status,a.attend_date,cl.Call_Log_No,cl.Customer_Name,cl.Call_Type_Code, cl.Site_ID, cl.Customer_ID, cl.SiteAdd1,  cl.site_latitude, cl.site_longitude, cl.IndusTTNumber,pt.Descr AS product 
		FROM 
		user_site_track AS ust 
		INNER JOIN local_user_mapping AS lum on (lum.StaffCode=ust.mob_user_staff_code)
		INNER JOIN attendance AS a ON(a.mob_user_staff_code=ust.mob_user_staff_code)
		INNER JOIN call_log AS cl on (ust.Call_Log_No=cl.Call_Log_No)
		INNER JOIN product_type AS pt ON(cl.DescrID=pt.DescrID)
		WHERE ust.mob_user_staff_code=? and DATE(ust.track_date) BETWEEN ? and ? and ust.Call_Log_No!='0' and ust.status='at_site' group by groupbyfield order by add_date asc";
  
		return $result = $db->fetchAll($query, array($params['user_visit'], $params['sitevisit_from'], $params['sitevisit_to']));
	}

	
    public function getFsrReportsByDate($params)
	{
		$db =  Zend_Db_Table::getDefaultAdapter();
		$query = "SELECT  DATE(fd.fsr_fill_date) AS add_date, DATE_FORMAT(fd.fsr_fill_date,'%H:%i:%s') TIMEONLY,
		lum.StaffCode, lum.StaffName, cl.Customer_Name,cl.Call_Type_Code,pt.Descr AS product, cl.Site_ID, cl.Customer_ID, cl.SiteAdd1, cl.Call_Log_No, cl.site_latitude, cl.site_longitude, cl.IndusTTNumber, fd.fsr_closed_lat, fd.fsr_closed_long,fd.fsr_where_closed
		FROM 
		fsr_detail AS fd 
		INNER JOIN local_user_mapping AS lum on (lum.StaffCode=fd.mob_user_staff_code)
		INNER JOIN call_log AS cl on (fd.Call_Log_No=cl.Call_Log_No)
		INNER JOIN product_type AS pt ON (cl.DescrID=pt.DescrID)
		WHERE fd.mob_user_staff_code=? and DATE(fd.fsr_fill_date) BETWEEN ? and ? and fd.Call_Log_No!='0' order by add_date asc";

		return $result = $db->fetchAll($query, array($params['user_fsr'], $params['fsr_from'], $params['fsr_to']));
	}

	
    public function getTicketReportsByDate($params)
	{
		$db =  Zend_Db_Table::getDefaultAdapter();
		$query = "SELECT DATE(fd.fsr_fill_date) AS add_date, DATE_FORMAT(fd.fsr_fill_date,'%H:%i:%s') TIMEONLY,
		lum.StaffName,lum.StaffCode, cl.Customer_Name, cl.Call_Type_Code,pt.Descr AS product,cl.Site_ID, cl.Customer_ID, cl.SiteAdd1, cl.site_latitude, cl.site_longitude,if(cl.IndusTTDT, cl.IndusTTDT,cl.Call_Log_DT) AS job_open_time,fd.tt_spare,fd.job_process_status,fd.job_process_status_time,cl.Call_Log_No, cl.IndusTTNumber, fd.fsr_closed_lat, fd.fsr_closed_long,fd.fsr_where_closed, cl.job_Scheduling_Status,fd.id AS fsr_no
		FROM 
		fsr_detail AS fd 
		INNER JOIN local_user_mapping AS lum on (lum.StaffCode=fd.mob_user_staff_code)
		INNER JOIN call_log AS cl on (fd.Call_Log_No=cl.Call_Log_No) INNER JOIN product_type AS pt ON(pt.DescrID=cl.DescrID)
		WHERE fd.mob_user_staff_code ='".$params['user_dis']."' and DATE(fd.fsr_fill_date) BETWEEN '".$params['ticket_from']."' and '".$params['ticket_to']."' and fd.Call_Log_No!='0' order by add_date asc"; 

		return $result = $db->fetchAll($query);
	}
	
	public function getPickChooseData($params)
	{
		$db =  Zend_Db_Table::getDefaultAdapter();

		// AND and DATE(attend_date)  between '".$params['pick_from']."' and '".$params['pick_to']."'
		$sqlparam = "";
		$groupby ="";
		if($params['totalloginhours'])
		{
			$sqlparam .= " ,total_login_hours";
		}
		if($params['fsrfillonsite'])
		{
			$sqlparam .= " , (
				select count(*) from fsr_detail where DATE(fsr_fill_date)=DATE(a.attend_date) and mob_user_staff_code=lum.StaffCode and fsr_where_closed='onsite'
			) as fsrfillonsite";
		}
		
		if($params['fsrfilloffsite'])
		{
			$sqlparam .= " , (
				select count(*) from fsr_detail where DATE(fsr_fill_date)=DATE(a.attend_date) and mob_user_staff_code=lum.StaffCode and fsr_where_closed='offsite'
			) as fsrfilloffsite";
		}
		
		if($params['ttclosedonsite'])
		{
			$sqlparam .= " , (
				select count(*) from call_log where DATE(tt_closed_date)=DATE(a.attend_date) and curr_Alloted_Eng_Code=lum.StaffCode and tt_closed_status='onsite'
			) as ttclosedonsite";
		}
		
		if($params['ttclosedoffsite'])
		{
			$sqlparam .= " , (
				select count(*) from call_log where DATE(tt_closed_date)=DATE(a.attend_date) and curr_Alloted_Eng_Code=lum.StaffCode and tt_closed_status='offsite'
			) as ttclosedoffsite";
		}
		
		if($params['sitevisitcount'])
		{
			$sqlparam .= " , (
				select count(*) from user_site_track where DATE(track_date)=DATE(a.attend_date) and mob_user_staff_code=lum.StaffCode and status='at_site'
			) as sitevisitcount";
		}
		
		$jointab = "";
		$cond = "";
		if(count($params['tttype']) || count($params['ttproducttype'])  || count($params['ttstatus']))
		{
			if(count($params['tttype']))
			{
				$str = implode(",",$params['tttype']);
				$str = "'".str_replace(",","','",$str)."'";
				$sqlparam .= " ,cl.Call_Type_Code";
				$conda = " cl.Call_Type_Code in ($str)";
			}
			if(count($params['ttproducttype']))
			{
				$str = implode(",",$params['ttproducttype']);
				$str = "'".str_replace(",","','",$str)."'";
				$sqlparam .= " ,pt.ComplaintDescrGroup";
				if($conda)
				{
					$condb = " and (".$conda." OR pt.ComplaintDescrGroup in ($str)";
				}
				else
				{
					$conda = " cl.product in ($str)";
				}	
			}
			
			if(count($params['ttstatus']))
			{
				$str = implode(",",$params['ttstatus']);
				$str = "'".str_replace(",","','",$str)."'";
				$sqlparam .= " ,d.job_process_status";
				
				if($condb)
				{
					$condc = $condb. " OR d.job_process_status in ($str))";
				}
				else if($conda)	
				{
					$condb = " and (".$conda." OR d.job_process_status in ($str)";
				}
				else
				{
					$conda = " d.job_process_status in ($str)";
				}
			}
			
			if($condc)
			{
				$cond = $condc;
			}
			else if($condb)
			{
				$cond = $condb.")";
			}
			else if($conda)	
			{
				$cond = " and ".$conda;
			}
			
			$sqlparam .= " ,CONCAT(cl.Call_Log_No,DATE(d.track_date)) as unique_date,cl.Call_Log_No,cl.Customer_Name, cl.Call_Type_Code,cl.Site_ID, cl.Customer_ID, cl.SiteAdd1, cl.site_latitude, cl.site_longitude,if(cl.IndusTTDT, cl.IndusTTDT,cl.Call_Log_DT) AS job_open_time, cl.IndusTTNumber,d.track_date,DATE_FORMAT(d.track_date,'%H:%i:%s') JOB_TIMEONLY,d.real_job_process_status,pt.ComplaintDescrGroup";
			
			$jointab = " LEFT JOIN day_wise_ticket_status as d on (d.mob_user_staff_code=lum.StaffCode ) 
			INNER JOIN call_log as cl on (cl.Call_Log_No=d.Call_Log_No)
			INNER JOIN product_type as pt on (pt.DescrID=cl.DescrID)
			";
			$groupby = " GROUP BY unique_date";
		}
	if($params['absent'] && !$params['present'])
	{
		$cond .= " and a.status=3";
	}	
	else if(!$params['absent'] && $params['present'])
	{
		$cond .= " and (a.status=1 or a.status=2)";
	}
    $query = "select 
		DATE(a.attend_date) AS add_date, DATE_FORMAT(a.attend_date,'%H:%i:%s') TIMEONLY,
		lum.StaffCode, lum.StaffName,if(a.status=3,'Absent','Present') as attend
		$sqlparam
		from local_user_mapping as lum 
		INNER join attendance as a on 
		(lum.StaffCode=a.mob_user_staff_code) 
		$jointab
		where 
		lum.StaffCode='".$params['pick_user']."' and DATE(a.attend_date) BETWEEN '".$params['pick_from']."' and '".$params['pick_to']."'
		$cond $groupby
		";

		return $result = $db->fetchAll($query);
	}
	
	
	public function getAllTotalOpenJob($StaffCode)
	{
	    $db =  Zend_Db_Table::getDefaultAdapter();
		$date = date("Y-m-d");
		$query = "select count(*) as total_processing from day_wise_ticket_status as cl left join local_user_mapping as lu on (cl.mob_user_cmsstaff_code=lu.CMSStaffStockCode) where cl.job_process_status='Open' and schedule_status!=0 and track_date = '".$date."' and lu.StaffCode ='".$UserStaffCode."' ";  
		//die;
		$result = $db->fetchRow($query);
		$openjobstatusArr['opencount'] = $result['total_processing']?$result['total_processing']:0;
		return $openjobstatusArr;
	}
	
	
	public function getAllTotalPendingJob($StaffCode)
	{
	    $db =  Zend_Db_Table::getDefaultAdapter();
	    $date = date("Y-m-d");
	    $query = "select count(*) as total_pending from day_wise_ticket_status as cl left join local_user_mapping as lu on (cl.mob_user_cmsstaff_code=lu.CMSStaffStockCode) where (cl.job_process_status!='Closed' and cl.job_process_status!='Open') and schedule_status!=0 and track_date = '".$date."' and lu.StaffCode ='".$StaffCode."' "; 
		$result = $db->fetchRow($query);
		$pendingjobstatusArr['pendingcount'] = $result['total_pending']?$result['total_pending']:0;
		return $pendingjobstatusArr;
	}
	
	
	public function getAllTotalCloseJob($StaffCode)
	{   
	    $db =  Zend_Db_Table::getDefaultAdapter();
	    $date = date("Y-m-d");
	    $query = "select count(*) as total_complete from day_wise_ticket_status as cl left join local_user_mapping as lu on (cl.mob_user_cmsstaff_code=lu.CMSStaffStockCode) where cl.job_process_status='Closed' and schedule_status!=0
		and track_date = '".$date."' and lu.StaffCode ='".$StaffCode."' "; 
		$result = $db->fetchRow($query);
		$closejobstatusArr['closedcount'] = $result['total_complete']?$result['total_complete']:0;
		return $closejobstatusArr;
	}
	
	
	public function getAtSiteTime($StaffCode,$job_id,$date)
	{   
	    $db =  Zend_Db_Table::getDefaultAdapter();
	    $query = "select track_date AS at_site_time from user_site_track where mob_user_staff_code='".$StaffCode."' and Call_Log_No='".$job_id."' and DATE(track_date)='".$track_date."' and status='at_site'"; 
		$result = $db->fetchRow($query);
		return $result;
	}
	
	public function getLeftSiteTime($StaffCode,$job_id,$date)
	{   
	    $db =  Zend_Db_Table::getDefaultAdapter();
	    $query = "select track_date AS left_site_time from user_site_track where mob_user_staff_code='".$StaffCode."' and Call_Log_No='".$job_id."' and DATE(track_date)='".$track_date."' and status='left_site'"; 
		$result = $db->fetchRow($query);
		return $result;
	}
	
	
	public function getAttendanceStartTime($StaffCode,$date)
	{   
	    $db =  Zend_Db_Table::getDefaultAdapter();
	    $query = "select attend_date AS start_attend_date from attendance where mob_user_staff_code='".$StaffCode."' and DATE(attend_date)='".$track_date."' and status='1'"; 
		$result = $db->fetchRow($query);
		return $result;
	}
	
	public function getAttendanceEndTime($StaffCode,$date)
	{   
	    $db =  Zend_Db_Table::getDefaultAdapter();
	    $query = "select attend_date AS end_attend_date from attendance where mob_user_staff_code='".$StaffCode."' and DATE(attend_date)='".$track_date."' and status='2'"; 
		$result = $db->fetchRow($query);
		return $result;
	}
	
	
	public function getTotalSiteVisitCount($StaffCode,$date)
	{   
	    $db =  Zend_Db_Table::getDefaultAdapter();
	    $date = date("Y-m-d");
	    $query = "select count(*) as total_site_visit from user_site_track where mob_user_staff_code='".$StaffCode."' and DATE(track_date)='".$track_date."' and status='at_site' "; 
		$result = $db->fetchRow($query);
		$totalvisitArr['total_visit_site'] = $result['total_site_visit']?$result['total_site_visit']:0;
		return $totalvisitArr;
	}
	

	
}

