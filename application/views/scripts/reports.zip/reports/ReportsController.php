<?php

/***************************************************************
 * Appstudioz Technologies Pvt. Ltd.
 * File Name   : ReportsController.php
 * File Description  : Reports Controller
 * Created By : Praveen Kumar
 * Created Date: 11 September 2013
 ***************************************************************/
 
class ReportsController extends Zend_Controller_Action
{
    var $dbAdapter;
	
    public function init()
    {
	
		/* Initialize action controller here */
		$bootstrap = $this->getInvokeArg('bootstrap');
		$aConfig = $bootstrap->getOptions();
	    $this->view->siteurl = $aConfig['site']['image']['url'];
		$this->dbAdapter = Zend_Db_Table::getDefaultAdapter();
        $auth = Zend_Auth::getInstance();
		$authStorage = $auth->getStorage();
		$StaffCode = $authStorage->read()->StaffCode;
		$users = new Application_Model_Users();
		$logout_details = $users->getUserLoginDetailByStaffCode($StaffCode);
		$this->view->last_login = $logout_details['login_time'];			
    }

	/**
	* manageUsers() method is used to users list of under supervisor
	* @param Null
	* @return Array 
	*/	
    public function indexAction()
    {   
		$this->checklogin();
		$user = new Application_Model_Users();
		
        $this->view->users = $result;
		$params = $this->getRequest()->getParams();
		$this->view->params = $params;
		$admin = new Application_Model_Admin($params);
		$auth = Zend_Auth::getInstance();
		$authStorage = $auth->getStorage();
		$role = $authStorage->read()->role;
		$this->view->selectRole = $admin->getRoles($role,$params['role']);
		
		if($role && $params['role'])
		{
		    $this->view->user = $admin->getAllUserDetails();
		}

    }
	
	
	public function distanceReportsAction()
	{
		$this->_helper->layout()->disableLayout();
		$this->checklogin();
		$reports = new Application_Model_Reports();
		$params = $this->getRequest()->getParams();

		$this->view->params = $params;
		$reportscome = $reports->getTravelDistanceByDate($params);
		$this->view->reports = $reportscome;

			if($params['DistanceGenerate'] == 'Generate')
			{
			
				require_once 'PHPExcel/Classes/PHPExcel.php';
				if(!$params['user_dis'])
				{
					$error_msg = 'Please select User.';
				}
				else if(!$params['distance_from'])
				{
					$error_msg = 'Please select from date.';
				}
				else if(!$params['distance_to'])
				{
					$error_msg = 'Please select to date.';
				}
				

				if(!$reportscome || !count($reportscome) || $error_msg)
				{
					if($error_msg)
					{
						$this->view->error_msg = $error_msg;
					}
					else
					{
						$this->view->error_msg = 'No record found for export.';
					}
					
				}
				else
				{
				
					$objPHPExcel = new PHPExcel();
					$objPHPExcel->getProperties()->setCreator("Saurabh Singh")
								 ->setLastModifiedBy("Saurabh Singh")
								 ->setTitle("Office 2007 XLSX  Document")
								 ->setSubject("Office 2007 XLSX  Document")
								 ->setDescription("Document for Office 2007 XLSX, generated using PHP classes.")
								 ->setKeywords("office 2007 openxml php")
								 ->setCategory("Field user distance traveled by date");
					// Add some data
					$objPHPExcel->getActiveSheet()->setCellValue('A1', 'Sr. No.')
												  ->setCellValue('B1', 'Date')
												  ->setCellValue('C1', 'Time')
												  ->setCellValue('D1', 'Enggn Name')
												  ->setCellValue('E1', 'Enggn Code')
												  ->setCellValue('F1', 'Customer Name')
												  ->setCellValue('G1', 'Site Id')
												  ->setCellValue('H1', 'Customer Site Id')
												  ->setCellValue('I1', 'Site Address')
												  ->setCellValue('J1', 'Site Lat/Long')
												  ->setCellValue('K1', 'TT No')
												  ->setCellValue('L1', 'Customer TT No.')
												  ->setCellValue('M1', 'From Lat/Long')
												  ->setCellValue('N1', 'To Lat/Long')
												  ->setCellValue('O1', 'Distance Travelled')
												  ->setCellValue('P1', 'Total Distance Travelled');
							$default_border = array(
									'style' => PHPExcel_Style_Border::BORDER_THIN,
									'color' => array('rgb'=>'000000')
								);
								
								$style_header = array(
									'fill' => array(
										'type' => PHPExcel_Style_Fill::FILL_SOLID,
										'color' => array('rgb'=>'999999')
									)
								);
					$objPHPExcel->getActiveSheet()->getStyle('A1:P1')->applyFromArray( $style_header );	
					$i = 2;		
					foreach($reportscome as $data)			
					{
						$total_distance_travelled = $reports->getTotalTravelledDistance($data['StaffCode'],$data['add_date']);
						$latStartArr = $reports->getStartLatLong($data['StaffCode'],$data['add_date']);
						$latEndArr = $reports->getEndLatLong($data['StaffCode'],$data['add_date']);
				
						$objPHPExcel->setActiveSheetIndex(0)
								->setCellValue('A'.$i, $i-1)
								->setCellValue('B'.$i, date("d F, Y",strtotime($data['add_date'])))	
								->setCellValue('C'.$i, $data['TIMEONLY'])
								->setCellValue('D'.$i, $data['StaffName'])
								->setCellValue('E'.$i, $data['StaffCode'])
								->setCellValue('F'.$i, $data['Customer_Name'])
								->setCellValue('G'.$i, $data['Site_ID'])
								->setCellValue('H'.$i, $data['Customer_ID'])
								->setCellValue('I'.$i, $data['SiteAdd1'])
								->setCellValue('J'.$i, $data['site_latitude']?number_format($data['site_latitude'],3).'/'.number_format($data['site_longitude'],3):'N/A')
								->setCellValue('K'.$i, $data['Call_Log_No'])
								->setCellValue('L'.$i, $data['IndusTTNumber'])
								->setCellValue('M'.$i, $latStartArr['lat']?number_format($latStartArr['lat'],3).'/'.number_format($latStartArr['longitude'],3):'N/A')
								->setCellValue('N'.$i, $latEndArr['lat']?number_format($latEndArr['lat'],3).'/'.number_format($latEndArr['longitude'],3):'N/A')
								->setCellValue('O'.$i, $data['distance_travelled'])
								->setCellValue('P'.$i, $total_distance_travelled);
							$i++;	
					}
					$objPHPExcel->setActiveSheetIndex(0);
					
					// Redirect output to a client’s web browser (Excel2007)
	
					header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
					header('Content-Disposition: attachment;filename="user_distance_traveled.xlsx"');
					header('Cache-Control: max-age=0'); 

	
					$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
					$objWriter->save('php://output');

					exit;
				}
			}
		
		
		
		
	}
	
	/*
	 * timeSpendtReportsAction()
	 * used to generate time spent by field user	
	 * 	
	 */
	
	public function timeSpentReportsAction()
	{
		$this->_helper->layout()->disableLayout();
		$this->checklogin();
		$reports = new Application_Model_Reports();
		$params = $this->getRequest()->getParams();
        //echo "<pre>"; print_r($params);
		$this->view->params = $params;
		$reportscome = $reports->getTimeSpendByDate($params);
		//echo "<pre>";print_r($reportscome);die;
		$this->view->reports = $reportscome; 
		
			if($params['TimeSpendGenerate'] == 'Generate')
			{
			    require_once 'PHPExcel/Classes/PHPExcel.php';
				
				if(!$params['user_spend'])
				{
					$error_msg = 'Please select User.';
				}
				else if(!$params['time_spend_from'])
				{
					$error_msg = 'Please select from date.';
				}
				else if(!$params['time_spend_to'])
				{
					$error_msg = 'Please select to date.';
				}
				if(!$reports || !count($reports) || $error_msg)
				{
					if($error_msg)
					{
						$this->view->error_msg = $error_msg;
					}
					else
					{
						$this->view->error_msg = 'No record found for export.';
					}
					
				}
				else
				{
                    
					$objPHPExcel = new PHPExcel();
					$objPHPExcel->getProperties()->setCreator("Saurabh Singh")
								 ->setLastModifiedBy("Saurabh Singh")
								 ->setTitle("Office 2007 XLSX  Document")
								 ->setSubject("Office 2007 XLSX  Document")
								 ->setDescription("Document for Office 2007 XLSX, generated using PHP classes.")
								 ->setKeywords("office 2007 openxml php")
								 ->setCategory("Field user distance traveled by date");
					// Add some data
					$objPHPExcel->getActiveSheet()->setCellValue('A1', 'Sr. No.')
												  ->setCellValue('B1', 'Date')
												  ->setCellValue('C1', 'Time')
												  ->setCellValue('D1', 'Enggn Name')
												  ->setCellValue('E1', 'Enggn Code')
												  ->setCellValue('F1', 'Customer Name')
												  ->setCellValue('G1', 'Site Id')
												  ->setCellValue('H1', 'Customer Site Id')
												  ->setCellValue('I1', 'Site Address')
												  ->setCellValue('J1', 'Site Lat/Long')
												  ->setCellValue('K1', 'TT No')
												  ->setCellValue('L1', 'From Lat/Long')
												  ->setCellValue('M1', 'To Lat/Long')
												  ->setCellValue('N1', 'Time Spend')
												  ->setCellValue('O1', 'Total Time Spend')
												   ->setCellValue('P1', 'TT No')
												  ->setCellValue('Q1', 'From Lat/Long')
												  ->setCellValue('R1', 'To Lat/Long')
												  ->setCellValue('S1', 'Time Spend')
												  ->setCellValue('T1', 'Total Time Spend')
												   ->setCellValue('U1', 'TT No')
												  ->setCellValue('V1', 'From Lat/Long')
												  ->setCellValue('W1', 'To Lat/Long')
												  ->setCellValue('X1', 'Time Spend')
												  ->setCellValue('Y1', 'Total Time Spend');					  
							$default_border = array(
									'style' => PHPExcel_Style_Border::BORDER_THIN,
									'color' => array('rgb'=>'000000')
								);
								
								$style_header = array(
									'fill' => array(
										'type' => PHPExcel_Style_Fill::FILL_SOLID,
										'color' => array('rgb'=>'999999')
									)
								);
					$objPHPExcel->getActiveSheet()->getStyle('A1:P1')->applyFromArray( $style_header );	
					$i = 2;		
					foreach($reportscome as $data)			
					{
						$total_distance_travelled = $reports->getTotalTravelledDistance($data['StaffCode'],$data['add_date']);
						$latStartArr = $reports->getStartLatLong($data['StaffCode'],$data['add_date']);
						$latEndArr = $reports->getEndLatLong($data['StaffCode'],$data['add_date']);
				
						$objPHPExcel->setActiveSheetIndex(0)
								->setCellValue('A'.$i, $i-1)
								->setCellValue('B'.$i, $data['add_date'])	
								->setCellValue('C'.$i, $data['TIMEONLY'])
								->setCellValue('D'.$i, $data['StaffName'])
								->setCellValue('E'.$i, $data['StaffCode'])
								->setCellValue('F'.$i, $data['Customer_Name'])
								->setCellValue('G'.$i, $data['Site_ID'])
								->setCellValue('H'.$i, $data['Customer_ID'])
								->setCellValue('I'.$i, $data['SiteAdd1'])
								->setCellValue('J'.$i, $data['site_latitude']?number_format($data['site_latitude'],3).'/'.number_format($data['site_longitude'],3):'N/A')
								->setCellValue('K'.$i, $data['Call_Log_No'])
								->setCellValue('L'.$i, $data['notmoving_startlatlong']?number_format($data['notmoving_startlatlong'],3):'N/A')
								->setCellValue('M'.$i, $data['notmoving_endlatlong']?number_format($data['notmoving_endlatlong'],3):'N/A')
								->setCellValue('N'.$i, $data['notmoving_time_spend']?$data['notmoving_time_spend']:'N/A')
								->setCellValue('O'.$i, $data['notmoving_total_time_spend']?$data['notmoving_total_time_spend']:'N/A')
								->setCellValue('P'.$i, $data['Call_Log_No'])
								->setCellValue('Q'.$i, $data['moving_startlatlong']?$data['moving_startlatlong']:'N/A')
								->setCellValue('R'.$i, $data['moving_endlatlong']?number_format($data['moving_endlatlong'],3):'N/A')
								->setCellValue('S'.$i, $data['moving_time_spend']?number_format($data['moving_time_spend'],3):'N/A')
								->setCellValue('T'.$i, $data['moving_total_time_spend']?$data['moving_total_time_spend']:'N/A')
								->setCellValue('U'.$i, $data['Call_Log_No'])
								->setCellValue('V'.$i, $data['atsite_startlatlong']?$data['atsite_startlatlong']:'N/A')
								->setCellValue('W'.$i, $data['atsite_endlatlong']?number_format($data['atsite_endlatlong'],3):'N/A')
								->setCellValue('X'.$i, $data['atsite_time_spend']?number_format($data['atsite_time_spend'],3):'N/A')
								->setCellValue('Y'.$i, $data['atsite_total_time_spend']?$data['atsite_total_time_spend']:'N/A');
							$i++;	
					}
					$objPHPExcel->setActiveSheetIndex(0);
					
					// Redirect output to a client’s web browser (Excel2007)
	
					header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
					header('Content-Disposition: attachment;filename="tt_time_spend.xlsx"');
					header('Cache-Control: max-age=0'); 

					$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
					$objWriter->save('php://output');

					exit;
				}	
			}

		
	}


	public function attendanceReportsAction()
	{			
		$this->_helper->layout()->disableLayout();
		$this->checklogin();
		$reports = new Application_Model_Reports();
		$params = $this->getRequest()->getParams();

		$this->view->params = $params;
		$reportscome = $reports->getAttendanceByDate($params);
		$this->view->reports = $reportscome;
			if($params['AttendanceGenerate'] == 'Generate')
			{	
				require_once 'PHPExcel/Classes/PHPExcel.php';
				
				if(!$params['user_attend'])
				{
					$error_msg = 'Please select User.';
				}
				else if(!$params['attendance_from'])
				{
					$error_msg = 'Please select from date.';
				}
				else if(!$params['attendance_to'])
				{
					$error_msg = 'Please select to date.';
				}
				if(!$reports || !count($reports) || $error_msg)
				{
					if($error_msg)
					{
						$this->view->error_msg = $error_msg;
					}
					else
					{
						$this->view->error_msg = 'No record found for export.';
					}
					
				}
				else
				{

				$objPHPExcel = new PHPExcel();
					$objPHPExcel->getProperties()->setCreator("Saurabh Singh")
								 ->setLastModifiedBy("Saurabh Singh")
								 ->setTitle("Office 2007 XLSX  Document")
								 ->setSubject("Office 2007 XLSX  Document")
								 ->setDescription("Document for Office 2007 XLSX, generated using PHP classes.")
								 ->setKeywords("office 2007 openxml php")
								 ->setCategory("Field user time spend by date");
					// Add some data
					$objPHPExcel->getActiveSheet()->setCellValue('A1', 'Sr. No.')
												  ->setCellValue('B1', 'Date')
												  ->setCellValue('C1', 'Time')
												  ->setCellValue('D1', 'Enggn Name')
												  ->setCellValue('E1', 'Enggn Code')
												  ->setCellValue('F1', 'Day Start Time')
												  ->setCellValue('G1', 'Day Start Lat / Long')
												  ->setCellValue('H1', 'Day End Time')
												  ->setCellValue('I1', 'Day End Lat / Long')
												  ->setCellValue('J1', 'Total time')
												  ->setCellValue('K1', 'Attendance Status')
												  ->setCellValue('L1', 'Site Attended Count')
												  ->setCellValue('M1', 'Site Close Count')
												  ->setCellValue('N1', 'Site Pending Count');
							$default_border = array(
									'style' => PHPExcel_Style_Border::BORDER_THIN,
									'color' => array('rgb'=>'000000')
								);
								
								$style_header = array(
									'fill' => array(
										'type' => PHPExcel_Style_Fill::FILL_SOLID,
										'color' => array('rgb'=>'999999'),
									)
								);
					$objPHPExcel->getActiveSheet()->getStyle('A1:N1')->applyFromArray( $style_header );	
					$i = 2;		
					foreach($reportscome as $data)			
					{
						if($data['logout_date'] == '0000-00-00 00:00:00')
						{
						$logout_date = $data['add_date'].' 23:59:59';
						}
						else
						{
						$logout_date = $data['logout_date'];
						}
						$total_visit = $reports->getTotalSiteVisitCountByEmp($data['StaffCode'], $data['attend_date'],$logout_date);
						$total_close = $reports->getTotalSiteCloseByEmp($data['StaffCode'],$data['add_date']);
						$total_pending = $reports->getTotalSitePendingByEmp($data['StaffCode'],$data['add_date']);
							$objPHPExcel->setActiveSheetIndex(0)
								->setCellValue('A'.$i, $i-1)
								->setCellValue('B'.$i, date("d F, Y",strtotime($data['add_date'])))	
								->setCellValue('C'.$i, $data['TIMEONLY'])
								->setCellValue('D'.$i, $data['StaffName'])
								->setCellValue('E'.$i, $data['StaffCode'])
								->setCellValue('F'.$i, $data['attend_date'])
								->setCellValue('G'.$i, number_format($data['latitude'],3).'/'.number_format($data['longitude'],3))
								->setCellValue('H'.$i, $data['logout_date'])
								->setCellValue('I'.$i, $data['end_latitude']?number_format($data['end_latitude'],3).'/'.number_format($data['end_longitude'],3):'N/A')
								->setCellValue('J'.$i, $data['total_time'])
								->setCellValue('K'.$i, $data['daystatus'])
								->setCellValue('L'.$i, $total_visit)
								->setCellValue('M'.$i, $total_close)
								->setCellValue('N'.$i, $total_pending);
							$i++;	
					}
					$objPHPExcel->setActiveSheetIndex(0);
					// Redirect output to a client’s web browser (Excel2007)
					header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
					header('Content-Disposition: attachment;filename="Attendance_'.$params['user'].'.xlsx"');
					header('Cache-Control: max-age=0');

					$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
					$objWriter->save('php://output');

					exit;
				}	
			}	
	}	
	

	
	public function siteVisitReportsAction()
	{
		$this->_helper->layout()->disableLayout();
		$this->checklogin();
		$reports = new Application_Model_Reports();
		$params = $this->getRequest()->getParams();

		$this->view->params = $params;
		$reportscome = $reports->getTravelSiteCountByDate($params);
		
		$this->view->reports = $reportscome;
		
			if($params['SitevisitGenerate'] == 'Generate')
			{
				require_once 'PHPExcel/Classes/PHPExcel.php';
				if(!$params['user_visit'])
				{
					$error_msg = 'Please select User.';
				}
				else if(!$params['sitevisit_from'])
				{
					$error_msg = 'Please select from date.';
				}
				else if(!$params['sitevisit_to'])
				{
					$error_msg = 'Please select to date.';
				}
				

				if(!$reportscome || !count($reportscome) || $error_msg)
				{
					if($error_msg)
					{
						$this->view->error_msg = $error_msg;
					}
					else
					{
						$this->view->error_msg = 'No record found for export.';
					}
					
				}
				else
				{
					$objPHPExcel = new PHPExcel();
					$objPHPExcel->getProperties()->setCreator("Saurabh Singh")
								 ->setLastModifiedBy("Saurabh Singh")
								 ->setTitle("Office 2007 XLSX  Document")
								 ->setSubject("Office 2007 XLSX  Document")
								 ->setDescription("Document for Office 2007 XLSX, generated using PHP classes.")
								 ->setKeywords("office 2007 openxml php")
								 ->setCategory("Field user distance traveled by date");
					// Add some data
					$objPHPExcel->getActiveSheet()->setCellValue('A1', 'Sr. No.')
												  ->setCellValue('B1', 'Date')
												  ->setCellValue('C1', 'Time')
												  ->setCellValue('D1', 'Enggn Name')
												  ->setCellValue('E1', 'Enggn Code')
												  ->setCellValue('F1', 'Day Start Time')
												  ->setCellValue('G1', 'Day End Time')
												  ->setCellValue('H1', 'Total time')
												  ->setCellValue('I1', 'TT No')
												  ->setCellValue('J1', 'Customer TT No.')
												  ->setCellValue('K1', 'Customer Name')
												  ->setCellValue('L1', 'Call Type')
												  ->setCellValue('M1', 'Product')
												  ->setCellValue('N1', 'Site Id')
												  ->setCellValue('O1', 'Customer Site Id')
												  ->setCellValue('P1', 'Site Address')
												  ->setCellValue('Q1', 'Total Time At Site Status')
												  ->setCellValue('R1', 'Total count At Site Status');
							$default_border = array(
									'style' => PHPExcel_Style_Border::BORDER_THIN,
									'color' => array('rgb'=>'000000')
								);
								
								$style_header = array(
									'fill' => array(
										'type' => PHPExcel_Style_Fill::FILL_SOLID,
										'color' => array('rgb'=>'999999'),
									)
								);
					$objPHPExcel->getActiveSheet()->getStyle('A1:R1')->applyFromArray( $style_header );	
					$i = 2;		
					foreach($reportscome as $data)			
					{						
						// Calculate between total time attendance table
						$start_attend_Time = $reports->getAttendanceStartTime($data['StaffCode'],$data['add_date']);
						$end_attend_Time = $reports->getAttendanceEndTime($data['StaffCode'],$data['add_date']);
						$starttime = strtotime($start_attend_Time['start_attend_date']);
						$endtime = strtotime($end_attend_Time['end_attend_date']);
						$total_time_attance = $endtime - $starttime;
						$total_attendance_time = date("h:i",$total_time_attance);
						
						// Calculate between total time 
						$atSiteTime = $reports->getAtSiteTime($data['StaffCode'],$data['Call_Log_No'],$data['add_date']);
						$leftSiteTime = $reports->getLeftSiteTime($data['StaffCode'],$data['Call_Log_No'],$data['add_date']);
						$attime = strtotime($atSiteTime['at_site_time']);
						$lefttime = strtotime($leftSiteTime['left_site_time']);
						$timeDiff = $lefttime - $attime;
						$total_time = date("h:i",$timeDiff);
						
						// TOTAL SITE COUNT STATUS
						$total_site_count = $reports->getTotalSiteVisitCount($data['StaffCode'],$data['add_date']);
						
						if($data['status']==1) { 
						$attendance_start_time = date("d F, Y",strtotime($data['attend_date']));
						}
						
						if($data['status']==2) { 
						$attendance_end_time = date("d F, Y",strtotime($data['attend_date']));
						}
						
						
						$objPHPExcel->setActiveSheetIndex(0)
								->setCellValue('A'.$i, $i-1)
								->setCellValue('B'.$i, date("d F, Y",strtotime($data['add_date'])))	
								->setCellValue('C'.$i, $data['TIMEONLY'])
								->setCellValue('D'.$i, $data['StaffName'])
								->setCellValue('E'.$i, $data['StaffCode'])
								->setCellValue('F'.$i, $attendance_start_time)
								->setCellValue('G'.$i, $attendance_end_time)
								->setCellValue('H'.$i, $total_attendance_time)
								->setCellValue('I'.$i, $data['Call_Log_No'])
								->setCellValue('J'.$i, $data['Call_Log_No'])
								->setCellValue('K'.$i, $data['Customer_Name'])
								->setCellValue('L'.$i, $data['Call_Type_Code'])
								->setCellValue('M'.$i, $data['product'])
								->setCellValue('N'.$i, $data['Site_ID'])
								->setCellValue('O'.$i, $data['Customer_ID'])
								->setCellValue('P'.$i, $data['SiteAdd1'])
								->setCellValue('Q'.$i, $total_time)
								->setCellValue('R'.$i, $total_site_count['total_visit_site']);
							$i++;	
					}
					$objPHPExcel->setActiveSheetIndex(0);
					// Redirect output to a client’s web browser (Excel2007)
					header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
					header('Content-Disposition: attachment;filename="user_distance_traveled_'.$params['user'].'.xlsx"');
					header('Cache-Control: max-age=0');

					$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
					$objWriter->save('php://output');

					exit;
				}
			}
		
		
		
		
	}	
	
	
	
	public function fsrReportsAction()
	{
		$this->_helper->layout()->disableLayout();
		$this->checklogin();
		$reports = new Application_Model_Reports();
		$params = $this->getRequest()->getParams();

		$this->view->params = $params;
		$reportscome = $reports->getFsrReportsByDate($params);
		$this->view->reports = $reportscome;

			if($params['FsrGenerate'] == 'Generate')
			{
				require_once 'PHPExcel/Classes/PHPExcel.php';
				
				if(!$params['user_fsr'])
				{
					$error_msg = 'Please select User.';
				}
				else if(!$params['fsr_from'])
				{
					$error_msg = 'Please select from date.';
				}
				else if(!$params['fsr_to'])
				{
					$error_msg = 'Please select to date.';
				}
				

				if(!$reportscome || !count($reportscome) || $error_msg)
				{
					if($error_msg)
					{
						$this->view->error_msg = $error_msg;
					}
					else
					{
						$this->view->error_msg = 'No record found for export.';
					}
					
				}
				else
				{
				
					$objPHPExcel = new PHPExcel();
					$objPHPExcel->getProperties()->setCreator("Saurabh Singh")
								 ->setLastModifiedBy("Saurabh Singh")
								 ->setTitle("Office 2007 XLSX  Document")
								 ->setSubject("Office 2007 XLSX  Document")
								 ->setDescription("Document for Office 2007 XLSX, generated using PHP classes.")
								 ->setKeywords("office 2007 openxml php")
								 ->setCategory("FSR Reports");
					// Add some data
					$objPHPExcel->getActiveSheet()->setCellValue('A1', 'Sr. No.')
												  ->setCellValue('B1', 'Date')
												  ->setCellValue('C1', 'Time')
												  ->setCellValue('D1', 'Enggn Name')
												  ->setCellValue('E1', 'Enggn Code')
												  ->setCellValue('F1', 'Customer Name')
												  ->setCellValue('G1', 'Call Type')
												  ->setCellValue('H1', 'Product')
												  ->setCellValue('I1', 'Site Id')
												  ->setCellValue('J1', 'Customer Site Id')
												  ->setCellValue('K1', 'Site Address')
												  ->setCellValue('L1', 'Site Lat/Long')
												  ->setCellValue('M1', 'FSR Lat / Long')
												  ->setCellValue('N1', 'FSR Filled At Site Status');
							$default_border = array(
									'style' => PHPExcel_Style_Border::BORDER_THIN,
									'color' => array('rgb'=>'000000')
								);
								
								$style_header = array(
									'fill' => array(
										'type' => PHPExcel_Style_Fill::FILL_SOLID,
										'color' => array('rgb'=>'999999')
									)
								);
					$objPHPExcel->getActiveSheet()->getStyle('A1:N1')->applyFromArray( $style_header );	
					$i = 2;		
					foreach($reportscome as $data)			
					{
						$total_distance_travelled = $reports->getTotalTravelledDistance($data['StaffCode'],$data['add_date']);
						$latStartArr = $reports->getStartLatLong($data['StaffCode'],$data['add_date']);
						$latEndArr = $reports->getEndLatLong($data['StaffCode'],$data['add_date']);
				
						$objPHPExcel->setActiveSheetIndex(0)
								->setCellValue('A'.$i, $i-1)
								->setCellValue('B'.$i, date("d F, Y",strtotime($data['add_date'])))	
								->setCellValue('C'.$i, $data['TIMEONLY'])
								->setCellValue('D'.$i, $data['StaffName'])
								->setCellValue('E'.$i, $data['StaffCode'])
								->setCellValue('F'.$i, $data['Customer_Name'])
								->setCellValue('F'.$i, $data['Call_Type_Code'])
								->setCellValue('F'.$i, $data['product'])
								->setCellValue('G'.$i, $data['Site_ID'])
								->setCellValue('H'.$i, $data['Customer_ID'])
								->setCellValue('I'.$i, $data['SiteAdd1'])
								->setCellValue('J'.$i, $data['site_latitude']?number_format($data['site_latitude'],3).'/'.number_format($data['site_longitude'],3):'N/A')
								->setCellValue('K'.$i, $data['fsr_closed_lat']?number_format($data['fsr_closed_lat'],3).'/'.number_format($data['fsr_closed_long'],3):'N/A')
								->setCellValue('L'.$i, $data['fsr_where_closed']);
							$i++;	
					}
					$objPHPExcel->setActiveSheetIndex(0);
					
					// Redirect output to a client’s web browser (Excel2007)
	
					header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
					header('Content-Disposition: attachment;filename="user_distance_traveled.xlsx"');
					header('Cache-Control: max-age=0'); 

	
					$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
					$objWriter->save('php://output');

					exit;
				}
			}

	}
	
	
	public function ticketReportsAction()
	{
		$this->_helper->layout()->disableLayout();
		$this->checklogin();
		$reports = new Application_Model_Reports();
		$params = $this->getRequest()->getParams();

		$this->view->params = $params;
	
		$reportscome = $reports->getTicketReportsByDate($params);	
		$this->view->reports = $reportscome;

		if($params['DistanceGenerate'] == 'Generate')
		{
			require_once 'PHPExcel/Classes/PHPExcel.php';
			
			if(!$params['user_dis'])
			{
				$error_msg = 'Please select User.';
			}
			else if(!$params['ticket_from'])
			{
				$error_msg = 'Please select from date.';
			}
			else if(!$params['ticket_to'])
			{
				$error_msg = 'Please select to date.';
			}
			
			if(!$reports || !count($reports) || $error_msg)
			{
				if($error_msg)
				{
					$this->view->error_msg = $error_msg;
				}
				else
				{
					$this->view->error_msg = 'No record found for export.';
				}
				
			}
			else
			{

				$objPHPExcel = new PHPExcel();
				$objPHPExcel->getProperties()->setCreator("Saurabh Singh")
							 ->setLastModifiedBy("Saurabh Singh")
							 ->setTitle("Office 2007 XLSX  Document")
							 ->setSubject("Office 2007 XLSX  Document")
							 ->setDescription("Document for Office 2007 XLSX, generated using PHP classes.")
							 ->setKeywords("office 2007 openxml php")
							 ->setCategory("FSR Reports");
				// Add some data
				$objPHPExcel->getActiveSheet()->setCellValue('A1', 'Sr. No.')
											  ->setCellValue('B1', 'Date')
											  ->setCellValue('C1', 'Time')
											  ->setCellValue('D1', 'Enggn Name')
											  ->setCellValue('E1', 'Enggn Code')
											  ->setCellValue('F1', 'Customer Name')
											  ->setCellValue('G1', 'Call Type')
											  ->setCellValue('H1', 'Product')
											  ->setCellValue('I1', 'Site Id')
											  ->setCellValue('J1', 'Customer Site Id')
											  ->setCellValue('K1', 'Site Address')
											  ->setCellValue('L1', 'Site Lat/Long')
											  ->setCellValue('M1', 'TT Open Date & Time')
											  ->setCellValue('N1', 'Close with / Without spare')
											  ->setCellValue('O1', 'TT Close Date & Time')
											  ->setCellValue('P1', 'TT Pending Aging')
											  ->setCellValue('Q1', 'TT No')
											  ->setCellValue('R1', ' No Customer TT no')
											  //->setCellValue('S1', 'TT Status')
											  //->setCellValue('T1', 'TT Status Remarks')
											  ->setCellValue('S1', 'TT Schedule')
											  ->setCellValue('T1', 'FSR No');
											  //->setCellValue('W1', 'FSR Status')
											  //->setCellValue('X1', 'TT SLA Status');
						$default_border = array(
								'style' => PHPExcel_Style_Border::BORDER_THIN,
								'color' => array('rgb'=>'000000')
							);
							
							$style_header = array(
								'fill' => array(
									'type' => PHPExcel_Style_Fill::FILL_SOLID,
									'color' => array('rgb'=>'999999')
								)
							);
				$objPHPExcel->getActiveSheet()->getStyle('A1:N1')->applyFromArray( $style_header );	
				$i = 2;		
				foreach($reportscome as $data)			
				{
					$total_distance_travelled = $reports->getTotalTravelledDistance($data['StaffCode'],$data['add_date']);
					$latStartArr = $reports->getStartLatLong($data['StaffCode'],$data['add_date']);
					$latEndArr = $reports->getEndLatLong($data['StaffCode'],$data['add_date']);
					
					if($data['job_process_status'] == "Complete"){ 
					$complete_time = "Complete".' & '.$data['job_process_status_time'];
					}
					else { 
					$complete_time =  'N/A'; 
					}
					
					if($data['job_process_status'] == "Close_with_pending"){ 
					$pending_time =  $data['job_process_status_time']; 
					} 
					else { 
					$pending_time = 'N/A'; 
					}
					
					$objPHPExcel->setActiveSheetIndex(0)
							->setCellValue('A'.$i, $i-1)
							->setCellValue('B'.$i, date("d F, Y",strtotime($data['add_date'])))	
							->setCellValue('C'.$i, $data['TIMEONLY'])
							->setCellValue('D'.$i, $data['StaffName'])
							->setCellValue('E'.$i, $data['StaffCode'])
							->setCellValue('F'.$i, $data['Customer_Name'])
							->setCellValue('G'.$i, $data['Call_Type_Code'])
							->setCellValue('H'.$i, $data['product'])
							->setCellValue('I'.$i, $data['Site_ID'])
							->setCellValue('J'.$i, $data['Customer_ID'])
							->setCellValue('K'.$i, $data['SiteAdd1'])
							->setCellValue('L'.$i, $data['site_latitude']?number_format($data['site_latitude'],3).'/'.number_format($data['site_longitude'],3):'N/A')
							->setCellValue('M'.$i, $data['job_open_time']?$data['job_open_time']:'N/A')
							->setCellValue('N'.$i, ucfirst($data['tt_spare']))
							->setCellValue('O'.$i, $complete_time)
							->setCellValue('P'.$i, $pending_time)
							->setCellValue('Q'.$i, $data['Call_Log_No'])
							->setCellValue('R'.$i, $data['Customer_ID'])
							//->setCellValue('S'.$i, "N/A")
							//->setCellValue('T'.$i, "N/A")
							->setCellValue('S'.$i, $data['job_Scheduling_Status'])
							->setCellValue('T'.$i, $data['fsr_no']);
							//->setCellValue('W'.$i, "N/A")
							//->setCellValue('X'.$i, "N/A");
						$i++;	
				}
				$objPHPExcel->setActiveSheetIndex(0);
				
				// Redirect output to a client’s web browser (Excel2007)

				header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
				header('Content-Disposition: attachment;filename="tt_ticket_report.xlsx"');
				header('Cache-Control: max-age=0'); 

				$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
				$objWriter->save('php://output');

				exit;
			}
		}
	}
	

	public function pickChooseColReportsAction()
	{
		$this->_helper->layout()->disableLayout();
		$this->checklogin();
		$reports = new Application_Model_Reports();
		$params = $this->getRequest()->getParams();
		$this->view->params = $params;
	
		$reportscome = $reports->getPickChooseData($params);
        
		$this->view->reports = $reportscome;

		if($params['PickAndChooseGenerate'] == 'Generate')
		{
			require_once 'PHPExcel/Classes/PHPExcel.php';
			
			if(!$params['pick_user'])
			{
				$error_msg = 'Please select User.';
			}
			else if(!$params['pick_from'])
			{
				$error_msg = 'Please select from date.';
			}
			else if(!$params['pick_to'])
			{
				$error_msg = 'Please select to date.';
			}
			
			if(!$reports || !count($reports) || $error_msg)
			{
				if($error_msg)
				{
					$this->view->error_msg = $error_msg;
				}
				else
				{
					$this->view->error_msg = 'No record found for export.';
				}
			}
			else
			{
				$objPHPExcel = new PHPExcel();
				$objPHPExcel->getProperties()->setCreator("Saurabh Singh")
							 ->setLastModifiedBy("Saurabh Singh")
							 ->setTitle("Office 2007 XLSX  Document")
							 ->setSubject("Office 2007 XLSX  Document")
							 ->setDescription("Document for Office 2007 XLSX, generated using PHP classes.")
							 ->setKeywords("office 2007 openxml php")
							 ->setCategory("FSR Reports");
				// Add some data
/* 				$i = count($params) - 7 + 5;
				if(count($params['ttstatus']))
				{
					$i = $i - 1 + count($params['ttstatus']);
				}
				if($params['absent'] && $params['present'])
				{
					$i = $i - 1;
				}
				
				if(count($params['tttype']))
				{
					$i = $i - 1;
				}
				
				if(count($params['ttproducttype']))
				{
					$i = $i - 1;
				}
				
				if(count($params['tttype']) || count($params['ttproducttype']) || count($params['ttstatus']))
				{
					$i = $i + 11 ;
				}		
				echo chr(65);
				die; */
						$i + 4;
							$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, 1 , 'Sr. No.');
							$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, 1, 'Date');
							$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, 1, 'Time');
							$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, 1, 'Enggn Name');
							$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, 1, 'Enggn Code');
							
							if($params['absent'] || $params['present'])
							{
								$i++;
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($i, 1, 'Attendence');
							}
							if($params['totalloginhours'])
							{
								$i++;
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($i, 1, 'Total Login Hours');
							}
							if(count($params['tttype']) || count($params['ttproducttype'])  || count($params['ttstatus']))
							{
								$i++;
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($i, 1, 'Customer Name');
								$i++;
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($i, 1, 'Call Type');
								$i++;
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($i, 1, 'Product Type');
								$i++;
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($i, 1, 'TT Status');
								$i++;
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($i, 1, 'Site Id');
								$i++;
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($i, 1, 'Customer Site Id');
								$i++;
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($i, 1, 'Site Address');
								$i++;
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($i, 1, 'Site Lat/Long');
								$i++;
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($i, 1, 'TT Open Date & Time');
								$i++;
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($i, 1, 'Close with / Without spare');
								$i++;
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($i, 1, 'TT Close Date & Time');
								$i++;
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($i, 1, 'TT Pending Aging');
								$i++;
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($i, 1, 'TT No');
								$i++;
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($i, 1, 'Customer TT no');
							}
						if(count($params['ttstatus']))
						{
							if(in_array('Accepted',$params['ttstatus']))
							{
								$i++;
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($i, 1, 'Accepted Job');
							}
							if(in_array('Unaccepted',$params['ttstatus']))
							{
								$i++;
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($i, 1, 'Unaccepted Job');
							}
							if(in_array('Reallocated',$params['ttstatus']))
							{
								$i++;
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($i, 1, 'Reallocated Job');
							}
							if(in_array('Open',$params['ttstatus']))
							{	
								$i++;		
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($i, 1, 'Open Job');
							}
							if(in_array('Pending',$params['ttstatus']))
							{
								$i++;		
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($i, 1, 'Pending Job');
							}
							if(in_array('Closed',$params['ttstatus']))
							{
								$i++;	
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($i, 1, 'Closed Job');
							}
						}
							if($params['fsrfillonsite'])
							{
									$i++;
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($i, 1, 'FSR Filled Onsite');
							}
							if($params['fsrfilloffsite'])
							{	
								$i++;	
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($i, 1, 'FSR Filled Offsite');
							}
							if($params['ttclosedonsite'])
							{	
								$i++;		
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($i, 1, 'TT Closed Onsite');
							}
							if($params['ttclosedoffsite'])
							{	
								$i++;
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($i, 1, 'TT Closed Offsite');
							}
							if($params['sitevisitcount'])
							{
								$i++;
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($i, 1, 'Site Visit Count');
							}
							if($params['servicerunning'])
							{
								$i++;
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($i, 1, 'Service Running');
							}
							if($params['servicestopped'])
							{
								$i++;
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($i, 1, 'Service Stopped');
							}
							if($params['gpson'])
							{
								$i++;
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($i, 1, 'Mobile GPS On');
							}
							if($params['gpsoff'])
							{
								$i++;
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($i, 1, 'Mobile GPS Off');
							}
						$default_border = array(
								'style' => PHPExcel_Style_Border::BORDER_THIN,
								'color' => array('rgb'=>'000000')
							);
							
							$style_header = array(
								'fill' => array(
									'type' => PHPExcel_Style_Fill::FILL_SOLID,
									'color' => array('rgb'=>'999999')
								)
							);
				$objPHPExcel->getActiveSheet()->getStyle('A1:AG1')->applyFromArray( $style_header );	
				$j = 1;
								
				foreach($reportscome as $data)			
				{
					$j++;
					if($data['job_process_status'] == "Complete"){ 
					$complete_time = $data['job_process_status_time'];
					}
					else { 
					$complete_time =  'N/A'; 
					}
					
					if($data['job_process_status'] == "Close_with_pending"){ 
					$pending_time =  $data['job_process_status_time']; 
					} 
					else { 
					$pending_time = 'N/A'; 
					}
					
					$i = 4;
					$objPHPExcel->setActiveSheetIndex(0)->setCellValueByColumnAndRow(0,$j, $j-1);
					$objPHPExcel->setActiveSheetIndex(0)->setCellValueByColumnAndRow(1,$j, date("d F, Y",strtotime($data['add_date'])));	
					$objPHPExcel->setActiveSheetIndex(0)->setCellValueByColumnAndRow(2,$j, $data['TIMEONLY']);
					$objPHPExcel->setActiveSheetIndex(0)->setCellValueByColumnAndRow(3,$j, $data['StaffName']);
					$objPHPExcel->setActiveSheetIndex(0)->setCellValueByColumnAndRow(4,$j, $data['StaffCode']);
					if($params['absent'] || $params['present'])
					{
						$i++;
						$objPHPExcel->setActiveSheetIndex(0)->setCellValueByColumnAndRow($i,$j, $data['attend']);
					}
					if($params['total_login_hours'])
					{
						$i++;
						$objPHPExcel->setActiveSheetIndex(0)->setCellValueByColumnAndRow($i,$j, $data['total_login_hours']);
					}	

					if(count($params['tttype']) || count($params['ttproducttype'])  || count($params['ttstatus']))
					{
						$i++;
						$objPHPExcel->setActiveSheetIndex(0)->setCellValueByColumnAndRow($i,$j, $data['Customer_Name']);
						$i++;
						$objPHPExcel->setActiveSheetIndex(0)->setCellValueByColumnAndRow($i,$j, $data['Call_Type_Code']);
						$i++;
						$objPHPExcel->setActiveSheetIndex(0)->setCellValueByColumnAndRow($i,$j, $data['ComplaintDescrGroup']);
						$i++;
						$objPHPExcel->setActiveSheetIndex(0)->setCellValueByColumnAndRow($i,$j, $data['Site_ID']);
						$i++;
						$objPHPExcel->setActiveSheetIndex(0)->setCellValueByColumnAndRow($i,$j, $data['Customer_ID']);
						$i++;
						$objPHPExcel->setActiveSheetIndex(0)->setCellValueByColumnAndRow($i,$j, stripslashes($data['SiteAdd1']));
						$i++;
						$objPHPExcel->setActiveSheetIndex(0)->setCellValueByColumnAndRow($i,$j, $data['site_latitude']?$data['site_latitude'].'/'.$data['site_longitude']:'N/A');
						$i++;
						$objPHPExcel->setActiveSheetIndex(0)->setCellValueByColumnAndRow($i,$j, $data['job_open_time']?$data['job_open_time']:'N/A');
						$i++;
						$objPHPExcel->setActiveSheetIndex(0)->setCellValueByColumnAndRow($i,$j, $data['Call_Log_No']);
						$i++;
						$objPHPExcel->setActiveSheetIndex(0)->setCellValueByColumnAndRow($i,$j, $data['Customer_ID']);
					}
					if($params['unacceptedcount'])
					{
						$i++;
						$objPHPExcel->setActiveSheetIndex(0)->setCellValueByColumnAndRow($i,$j, $data['unacceptedcount']);
					}
					if($params['reallocatedcount'])
					{
						$i++;	
						$objPHPExcel->setActiveSheetIndex(0)->setCellValueByColumnAndRow($i,$j, $data['reallocatedcount']);
					}
					if($params['opencount'])
					{		
						$i++;		
						$objPHPExcel->setActiveSheetIndex(0)->setCellValueByColumnAndRow($i,$j, $data['opencount']);
					}
					if($params['pendingcount'])
					{	
						$i++;		
						$objPHPExcel->setActiveSheetIndex(0)->setCellValueByColumnAndRow($i,$j, $data['pendingcount']);
					}
					if($params['closedcount'])
					{		
						$i++;		
						$objPHPExcel->setActiveSheetIndex(0)->setCellValueByColumnAndRow($i,$j, $data['closedcount']);
					}
					if($params['fsrfillonsite'])
					{		
						$i++;		
						$objPHPExcel->setActiveSheetIndex(0)->setCellValueByColumnAndRow($i,$j, $data['fsrfillonsite']);
					}
					if($params['fsrfilloffsite'])
					{		
						$i++;		
						$objPHPExcel->setActiveSheetIndex(0)->setCellValueByColumnAndRow($i,$j, $data['fsrfilloffsite']);
					}
					if($params['ttclosedonsite'])
					{		
						$i++;	
						$objPHPExcel->setActiveSheetIndex(0)->setCellValueByColumnAndRow($i,$j, $data['ttclosedonsite']);
					}
					if($params['ttclosedoffsite'])
					{		
						$i++;	
						$objPHPExcel->setActiveSheetIndex(0)->setCellValueByColumnAndRow($i,$j, $data['ttclosedoffsite']);
					}
					if($params['sitevisitcount'])
					{		
						$i++;	
						$objPHPExcel->setActiveSheetIndex(0)->setCellValueByColumnAndRow($i,$j, $data['sitevisitcount']);
					}
					if($params['mobileclientrunning'])
					{		
						$i++;		
						$objPHPExcel->setActiveSheetIndex(0)->setCellValueByColumnAndRow($i,$j, $data['mobileclientrunning']);
					}
					if($params['mobileclientstopped'])
					{		
						$i++;		
						$objPHPExcel->setActiveSheetIndex(0)->setCellValueByColumnAndRow($i,$j, $data['mobileclientstopped']);
					}
					if($params['gpson'])
					{		
						$i++;		
						$objPHPExcel->setActiveSheetIndex(0)->setCellValueByColumnAndRow($i,$j, $data['gpson']);
					}
					if($params['gpsoff'])
					{		
						$i++;	
						$objPHPExcel->setActiveSheetIndex(0)->setCellValueByColumnAndRow($i,$j, $data['gpsoff']);
					}	
					
				}
				$objPHPExcel->setActiveSheetIndex(0);
				
				// Redirect output to a client’s web browser (Excel2007)

				header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
				header('Content-Disposition: attachment;filename="pick_choose_col.xlsx"');
				header('Cache-Control: max-age=0'); 

				$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
				$objWriter->save('php://output');

				exit;
			}
		}
	}
	
	public function checklogin()
	{
		$auth = Zend_Auth::getInstance();
		
		$errorMessage = ""; 
		/*************** check user identity ************/
		if(!$auth->hasIdentity())  
        {  
            $this->_redirect('admin/index');  
        } 
	}

}



